import os

SECRET_TOKEN = os.environ.get('SECRET_TOKEN', 'supersecret123')
COUNTRY = os.environ.get('COUNTRY', 'za')
